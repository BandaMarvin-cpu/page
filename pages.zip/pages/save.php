<?php
// Step 1: Include the config file
include 'config.php';

// Step 2: Establish a database connection
$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 3: Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Step 4: Retrieve the submitted form data
    $index = $_POST['id'];
    $item = $_POST['item'];
    $inventory = $_POST['inventory'];
    $availability = $_POST['availability'];

    // Step 5: Update the database with the new values
    $sql = "UPDATE inventory SET item='$item', inventory='$inventory', availability='$availability' WHERE `index`='$index'";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Step 6: Close the database connection
$conn->close(); 

// Step 7: Redirect back to the home page
header("Location: index.php");
exit();
?>
