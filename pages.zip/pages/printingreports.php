<!DOCTYPE html>
<html>
<head>
    <title>Your Web App</title>
    <!-- Include any necessary CSS stylesheets or libraries -->
</head>
<body>
    <!-- Your HTML content -->

    <div class="statistics-item">
        <button onclick="open3DPrintingReport()" style="color: #1e212a; background-color: #1e212a; border: none;">
            <label class="badge badge-outline-success badge-pill">3D Printing</label>
        </button>
    </div>

    <div id="reportContainer"></div>

    <!-- Include the jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <!-- Define the open3DPrintingReport() function -->
    <script>
        function open3DPrintingReport() {
            $.ajax({
                url: 'printreports.php',
                method: 'GET',
                success: function(response) {
                    var newWindow = window.open('', '_blank');
                    newWindow.document.write(response);
                    newWindow.document.close();
                },
                error: function(xhr, status, error) {
                    console.log(error);
                }
            });
        }
    </script>

</body>
</html>
